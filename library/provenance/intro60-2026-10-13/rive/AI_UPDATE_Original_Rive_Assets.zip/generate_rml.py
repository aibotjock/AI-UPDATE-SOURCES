from pathlib import Path
import math, random
from xml.sax.saxutils import escape

ROOT=Path(__file__).parent
DEST=ROOT/'neural_core'/'scene.rml'
next_id=100
def uid():
    global next_id
    next_id+=1
    return f'0:{next_id}'
def solid(c): return f'<SolidColor colorValue="{c}" name="Color"/>'
def fill(c): return f'<Fill name="Fill">{solid(c)}</Fill>'
def stroke(c,t=2,glow=0):
    return f'<Stroke name="Stroke" thickness="{t}" cap="round" join="round">{solid(c)}'+(f'<Feather strength="{glow}" name="Feather"/>' if glow else '')+'</Stroke>'
def ellipse(x,y,w,h,c=None,s=None,t=2,name='Ring',glow=0):
    ident=uid()
    return f'<Shape x="{x}" y="{y}" name="{name}" id="{ident}"><Ellipse width="{w}" height="{h}" originX="0.5" originY="0.5" name="Path"/>'+ (fill(c) if c else '')+(stroke(s,t,glow) if s else '')+'</Shape>'
def rect(x,y,w,h,c=None,s=None,t=2,r=16,rotation=0,name='Panel'):
    ident=uid()
    return f'<Shape x="{x}" y="{y}" rotation="{rotation}" name="{name}" id="{ident}"><Rectangle width="{w}" height="{h}" cornerRadiusTL="{r}" originX="0.5" originY="0.5" name="Path"/>'+ (fill(c) if c else '')+(stroke(s,t) if s else '')+'</Shape>'
def path(points,c=None,s='FF50DFFF',t=2,closed=False,name='Trace',glow=0):
    ident=uid()
    v=''.join(f'<StraightVertex x="{x:.2f}" y="{y:.2f}"/>' for x,y in points)
    return f'<Shape name="{name}" id="{ident}"><PointsPath isClosed="{str(closed).lower()}" isClockwise="true" name="Path">{v}</PointsPath>'+(fill(c) if c else '')+(stroke(s,t,glow) if s else '')+'</Shape>'
def poly(x,y,r,n=6,c=None,s=None,t=2,name='Hex'):
    return path([(x+r*math.cos(math.pi/6+i*2*math.pi/n),y+r*math.sin(math.pi/6+i*2*math.pi/n)) for i in range(n)],c,s,t,True,name)
def circle_arc(cx,cy,r,start,end,color,t=3,name='Arc',glow=0):
    points=[(cx+r*math.cos(a),cy+r*math.sin(a)) for a in [start+(end-start)*i/70 for i in range(71)]]
    return path(points,s=color,t=t,name=name,glow=glow)
def animation(id_, targets, duration=600):
    keys=''
    for target,prop,vals in targets:
        frames=''.join(f'<KeyFrameDouble frame="{f}" value="{v}" interpolationType="linear"/>' for f,v in vals)
        keys+=f'<KeyedObject objectId="{target}"><KeyedProperty property="{prop}">{frames}</KeyedProperty></KeyedObject>'
    return f'<LinearAnimation duration="{duration}" fps="60" loopValue="loop" name="Living motion" id="{id_}">{keys}</LinearAnimation>'
def board(name,content,targets,x=0):
    art,anim,sm,layer,state,style=[uid() for _ in range(6)]
    return f'<Artboard x="{x}" width="1200" height="1200" name="{name}" id="{art}" styleId="{style}" defaultStateMachineId="{sm}"><LayoutComponentStyle name="Artboard style" id="{style}"/><Fill name="Deep navy stage"><SolidColor colorValue="FF07111C" name="Stage color"/></Fill>{content}<StateMachine name="Default" id="{sm}"><StateMachineLayer name="Living scene" id="{layer}"><AnyState x="200" y="-120"/><ExitState x="400" y="-120"/><EntryState x="0" y="0"><StateTransition stateToId="{state}"/></EntryState><AnimationState x="200" y="0" animationId="{anim}" id="{state}"/></StateMachineLayer></StateMachine>{animation(anim,targets)}</Artboard>'

# Original neural network globe, authored and rendered in Rive (no third-party artwork).
parts=[]; targets=[]
for yy in range(3):
    for xx in range(3):
        parts.append(rect(578+xx*22,578+yy*22,12,12,c='FFF5D188',r=3,name='Processor gate'))
parts.append(poly(600,600,78,c='FF102C42',s='FFF4CC79',t=3,name='Central processor'))
parts.append(poly(600,600,105,s='FF70E7FF',t=2,name='Processor bezel'))
parts.append(poly(600,600,119,s='558DEEFF',t=1,name='Outer bezel'))
random.seed(17)
nodes=[]
for i in range(90):
    z=1-2*(i+.5)/90; a=i*math.pi*(3-math.sqrt(5)); rad=math.sqrt(1-z*z)
    x=600+425*rad*math.cos(a); y=600+425*z; depth=(rad*math.sin(a)+1)/2
    nodes.append((x,y,depth))
for i,(x,y,d) in enumerate(nodes):
    col='FFB0F3FF' if d>.6 else 'FF42AACA'
    parts.append(ellipse(x,y,4+7*d,4+7*d,col,name='Neural vertex'))
    if d>.75: parts.append(ellipse(x,y,22,22,s='225FDFFF',t=5,glow=8,name='Vertex glow'))
for i,(x,y,d) in enumerate(nodes):
    dist=sorted([(math.hypot(x-x2,y-y2),j) for j,(x2,y2,d2) in enumerate(nodes) if i!=j])[:3]
    for distance,j in dist:
        if j>i and distance<200:
            x2,y2,_=nodes[j]
            parts.append(path([(x,y),(x2,y2)],s='5545A5C9',t=.9,name='Network link'))
for r,w in [(430,1),(366,.8),(291,.8)]:
    parts.append(ellipse(600,600,r*2,r*2,s='4479DFFF',t=w,name='Network orbit'))
for w in [700,520,250]: parts.append(ellipse(600,600,w,860,s='265AD4F6',t=.8,name='Sphere meridian'))
for h in [650,390,150]: parts.append(ellipse(600,600,860,h,s='265AD4F6',t=.8,name='Sphere latitude'))
orbit=uid(); orbital=[]
for i in range(8):
    a=2*math.pi*i/8
    x,y=465*math.cos(a),465*math.sin(a)
    orbital.append(ellipse(x,y,12,12,c='FFF8D898' if i%3==0 else 'FF8CEFFF',name='Moving orbit point'))
    orbital.append(circle_arc(0,0,465,a+.06,a+.36,'99F5CF82' if i%3==0 else '8865E5FF',2,name='Orbit segment'))
parts.append(f'<Node x="600" y="600" name="Orbit carrier" id="{orbit}">'+''.join(orbital)+'</Node>')
targets.append((orbit,'rotation',[(0,0),(600,.72)]))
parts.append(ellipse(600,600,965,965,s='2250DDFF',t=12,glow=24,name='Outer atmosphere'))
core=board('Neural Core',''.join(parts),targets)

# Evaluation lens: a magnifying instrument over a verifiable code/check motif.
parts=[]; targets=[]
parts.append(path([(456,595),(410,640),(455,685)],s='FF93ECFF',t=13,name='Code left bracket'))
parts.append(path([(610,595),(656,640),(611,685)],s='FF93ECFF',t=13,name='Code right bracket'))
parts.append(path([(556,575),(512,705)],s='FFF5CF88',t=10,name='Code slash'))
parts.append(path([(645,440),(677,472),(738,408)],s='FFF5D598',t=12,name='Verified check'))
parts.append(ellipse(690,442,140,140,c='FF0D253B',s='FFF5D598',t=3,name='Verification badge'))
parts.append(rect(535,630,390,260,c='FF0B2137',s='664BD6FF',t=2,r=22,name='Evaluation card'))
for i in range(3): parts.append(rect(395+i*45,531,15,15,c=['FFECCB8D','FF73D8F4','FF5AA2C5'][i],r=7,name='Header indicator'))
parts.append(path([(340,563),(730,563)],s='334CAACD',t=1,name='Card divider'))
parts.append(ellipse(543,595,628,628,s='FF77E3FF',t=8,name='Lens rim'))
parts.append(ellipse(543,595,682,682,s='8867D7FF',t=1.5,name='Outer lens'))
parts.append(ellipse(543,595,600,600,s='4450BBD4',t=1,name='Inner lens'))
parts.append(circle_arc(543,595,342,-2.1,-.25,'FFF4CC83',7,name='Lens highlight'))
parts.append(path([(782,834),(1000,1052)],s='FF102A43',t=94,name='Magnifier grip'))
parts.append(path([(795,847),(996,1048)],s='8868D7F0',t=6,name='Grip inlay'))
parts.append(circle_arc(543,595,371,-2.8,-.45,'445FE9FF',18,name='Lens glow',glow=20))
scan=uid()
parts.append(f'<Node x="543" y="595" name="Instrument scanning" id="{scan}">'+circle_arc(0,0,325,-.45,.1,'887DEEFF',3,name='Scanning arc')+'</Node>')
targets.append((scan,'rotation',[(0,0),(600,6.2831855)]))
for a in [i*math.pi/8 for i in range(16)]:
    parts.append(path([(543+math.cos(a)*393,595+math.sin(a)*393),(543+math.cos(a)*407,595+math.sin(a)*407)],s='6665B7D5',t=2,name='Instrument graduation'))
lens=board('Evaluation Lens',''.join(parts),targets,x=1350)

# Task-and-value balance: cost/quality as distinct symbolic inputs, without fake numbers.
parts=[]; targets=[]
parts.append(path([(352,645),(390,680),(459,599)],s='FFF7D58C',t=14,name='Quality check'))
parts.append(ellipse(405,645,142,142,s='FFEECA7C',t=3,name='Quality medallion'))
for x,y in [(796,620),(813,650),(780,679)]:
    parts.append(ellipse(x,y,130,52,c='FF173348',s='FF79E6FF',t=3,name='Cost token'))
parts.append(path([(320,740),(486,740)],s='FF87DFFF',t=5,name='Quality tray'))
parts.append(path([(722,740),(888,740)],s='FF87DFFF',t=5,name='Cost tray'))
for x in [320,486,722,888]: parts.append(path([(x,740),(403 if x<600 else 805,466)],s='665ED8F4',t=2,name='Balance cable'))
beam=uid()
parts.append(f'<Node x="600" y="450" name="Value balance beam" id="{beam}">'+path([(-242,0),(242,0)],s='FFF6D38A',t=12,name='Balance beam')+'</Node>')
targets.append((beam,'rotation',[(0,-.07),(150,.07),(300,-.07),(450,.07),(600,-.07)]))
parts.append(poly(600,460,52,c='FF0B273B',s='FFF4CD81',t=3,name='Balance pivot'))
parts.append(path([(600,518),(600,910)],s='FF4AABC8',t=12,name='Balance column'))
parts.append(rect(600,923,360,28,c='FF245773',s='886BD9F2',r=14,name='Balance base'))
parts.append(ellipse(600,930,710,155,s='335CB5CC',t=1,name='Platform orbit'))
parts.append(ellipse(600,650,1070,1070,s='224FABC9',t=1,name='Value horizon'))
for i in range(24):
    a=i*2*math.pi/24
    parts.append(path([(600+500*math.cos(a),650+500*math.sin(a)),(600+512*math.cos(a),650+512*math.sin(a))],s='3354A2BF',t=1.8,name='Horizon tick'))
balance=board('Value Balance',''.join(parts),targets,x=2700)
DEST.write_text('<Rive version="1" kind="fragment">'+core+lens+balance+'</Rive>')
print(DEST)
