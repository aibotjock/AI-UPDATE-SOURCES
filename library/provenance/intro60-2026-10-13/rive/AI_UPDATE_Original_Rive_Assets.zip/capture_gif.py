from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import os, subprocess, shutil, json, hashlib
import xml.etree.ElementTree as ET

root=Path(__file__).parent.resolve()
project=root/'gif_scene'
project.mkdir(exist_ok=True)
tree=ET.parse(root/'neural_core'/'scene.rml')
artboard=next(a for a in tree.getroot().findall('Artboard') if a.attrib['name']=='Neural Core')
animation=artboard.find('LinearAnimation')
animation.set('duration','360')
keys=animation.find('KeyedObject').find('KeyedProperty').findall('KeyFrameDouble')
keys[-1].set('frame','360');keys[-1].set('value','6.2831855')
tree.write(project/'scene.rml',encoding='unicode')
(project/'rive.yaml').write_text('name: ai_update_neural_loop\nmain: Neural Core\n')
source=project/'scene.rml'
env=os.environ.copy()
env['LD_LIBRARY_PATH']=str(root/'linux-libs'/'usr'/'lib'/'x86_64-linux-gnu')
cli=str(root/'cli'/'bin'/'rive')
frames=root/'gif_frames';frames.mkdir(exist_ok=True)
workers=[]
for i in range(3):
    worker=root/'capture_projects'/f'worker{i}'
    worker.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(source,worker/'scene.rml')
    (worker/'rive.yaml').write_text(f'name: capture_worker_{i}\nmain: Neural Core\n')
    workers.append(worker)

commands=[]
def capture_batch(worker_num):
    records=[]
    for frame in range(worker_num,120,3):
        # One initial 60fps tick starts the state machine; then sample exactly 20fps.
        advance=1+frame*3
        image=frames/f'frame_{frame:03d}.png'
        command=[cli,str(workers[worker_num]),f'--screenshot={image}','--artboard=Neural Core',f'--advance={advance}']
        result=subprocess.run(command,env=env,text=True,capture_output=True)
        if result.returncode: raise RuntimeError(result.stdout+result.stderr)
        records.append({'frame':frame,'advance_60fps_frames':advance,'file':str(image),'command':command,'sha256':hashlib.sha256(image.read_bytes()).hexdigest()})
        if frame%15==worker_num: print(f'Worker {worker_num}: captured frame {frame}',flush=True)
    return records
with ThreadPoolExecutor(max_workers=3) as executor:
    for batch in executor.map(capture_batch,range(3)):commands.extend(batch)
commands.sort(key=lambda x:x['frame'])
encoder=['ffmpeg','-y','-framerate','20','-i',str(frames/'frame_%03d.png'),'-filter_complex','[0:v]scale=720:720:flags=lanczos,split[a][b];[a]palettegen=stats_mode=full[p];[b][p]paletteuse=dither=bayer:bayer_scale=3','-loop','0',str(root/'neural_core_6s.gif')]
result=subprocess.run(encoder,text=True,capture_output=True)
if result.returncode: raise RuntimeError(result.stderr)
proof={'origin':'Actual Rive CLI 1.5.1 headless captures of original Neural Core RML timeline','frames':120,'fps':20,'planned_duration_seconds':6,'gif_dimensions':[720,720],'encoding':'ffmpeg GIF palette generation and paletteuse; no video intermediate','commands':commands,'ffmpeg_command':encoder,'loop_animation':{'duration_60fps_frames':360,'orbit_rotation_radians':6.2831855}}
(root/'gif_capture_evidence.json').write_text(json.dumps(proof,indent=2))
print(str(root/'neural_core_6s.gif'),flush=True)
